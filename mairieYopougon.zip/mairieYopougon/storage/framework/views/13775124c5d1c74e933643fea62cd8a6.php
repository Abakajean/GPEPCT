<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50 py-8">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white shadow-xl rounded-lg overflow-hidden">
            <!-- En-tête avec titre -->
            <div class="bg-orange-500 px-6 py-4 border-b border-orange-600">
                <h1 class="text-2xl font-bold text-white">Modifier un acte de décès</h1>
                <p class="mt-1 text-orange-100">Mettez à jour les informations de l'acte</p>
            </div>

            <!-- Formulaire -->
            <form method="POST" action="<?php echo e(route('acte.deces.update', $acte)); ?>" class="p-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="space-y-6">
                    <!-- Numéro de registre -->
                    <div>
                        <label for="numero_registre" class="block text-sm font-medium text-gray-700">Numéro de registre (5 chiffres)</label>
                        <input type="text" id="numero_registre" name="numero_registre" value="<?php echo e(old('numero_registre', $acte->numero_registre)); ?>"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                            required>
                        <?php $__errorArgs = ['numero_registre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Section Défunt -->
                    <div class="border-t border-gray-200 pt-4">
                        <h2 class="text-lg font-medium text-gray-900 bg-green-50 px-3 py-2 rounded-md">
                            <i class="fas fa-user mr-2 text-orange-500"></i>Informations sur le défunt
                        </h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                            <!-- Nom défunt -->
                            <div>
                                <label for="nom_defunt" class="block text-sm font-medium text-gray-700">Nom du défunt</label>
                                <input type="text" id="nom_defunt" name="nom_defunt" value="<?php echo e(old('nom_defunt', $acte->nom_defunt)); ?>"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                                    required>
                                <?php $__errorArgs = ['nom_defunt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <!-- Date de décès -->
                            <div>
                                <label for="date_deces" class="block text-sm font-medium text-gray-700">Date du décès</label>
                                <input type="date" id="date_deces" name="date_deces" value="<?php echo e(old('date_deces', $acte->date_deces->format('Y-m-d'))); ?>"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                                    required>
                                <?php $__errorArgs = ['date_deces'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <!-- Lieu de décès -->
                            <div>
                                <label for="lieu_deces" class="block text-sm font-medium text-gray-700">Lieu du décès</label>
                                <input type="text" id="lieu_deces" name="lieu_deces" value="<?php echo e(old('lieu_deces', $acte->lieu_deces)); ?>"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                                    required>
                                <?php $__errorArgs = ['lieu_deces'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <!-- Cause de décès -->
                            <div class="md:col-span-2">
                                <label for="cause_deces" class="block text-sm font-medium text-gray-700">Cause du décès</label>
                                <textarea id="cause_deces" name="cause_deces" rows="3"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"><?php echo e(old('cause_deces', $acte->cause_deces)); ?></textarea>
                                <?php $__errorArgs = ['cause_deces'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Section Déclarant -->
                    <div class="border-t border-gray-200 pt-4">
                        <h2 class="text-lg font-medium text-gray-900 bg-green-50 px-3 py-2 rounded-md">
                            <i class="fas fa-user-edit mr-2 text-orange-500"></i>Informations sur le déclarant
                        </h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                            <!-- Nom déclarant -->
                            <div>
                                <label for="declarant_nom" class="block text-sm font-medium text-gray-700">Nom</label>
                                <input type="text" id="declarant_nom" name="declarant_nom" value="<?php echo e(old('declarant_nom', $acte->declarant_nom)); ?>"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                                    required>
                                <?php $__errorArgs = ['declarant_nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <!-- Prénom déclarant -->
                            <!-- <div>
                                <label for="declarant_prenoms" class="block text-sm font-medium text-gray-700">Prénoms</label>
                                <input type="text" id="declarant_prenoms" name="declarant_prenoms" value="<?php echo e(old('declarant_prenoms', $acte->declarant_prenoms)); ?>"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                                    required>
                                <?php $__errorArgs = ['declarant_prenoms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div> -->
                            
                            <!-- Profession déclarant -->
                            <div>
                                <label for="declarant_profession" class="block text-sm font-medium text-gray-700">Profession</label>
                                <input type="text" id="declarant_profession" name="declarant_profession" value="<?php echo e(old('declarant_profession', $acte->declarant_profession)); ?>"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                                    required>
                                <?php $__errorArgs = ['declarant_profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <!-- Adresse déclarant -->
                            <div>
                                <label for="declarant_adresse" class="block text-sm font-medium text-gray-700">Domicile</label>
                                <input type="text" id="declarant_domicile" name="declarant_domicile" value="<?php echo e(old('declarant_domicile', $acte->declarant_domicile)); ?>"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                                    required>
                                <?php $__errorArgs = ['declarant_domicile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Boutons d'action -->
                    <div class="flex justify-between pt-6 border-t border-gray-200">
                        <a href="<?php echo e(route('acte.deces.index')); ?>" 
                           class="inline-flex items-center px-4 py-2 bg-gray-200 border border-transparent rounded-md font-semibold text-gray-700 hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition duration-150 ease-in-out">
                            <i class="fas fa-arrow-left mr-2"></i> Retour
                        </a>
                        <button type="submit"
                                class="inline-flex items-center px-4 py-2 bg-orange-500 border border-transparent rounded-md font-semibold text-white hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 transition duration-150 ease-in-out">
                            <i class="fas fa-save mr-2"></i> Mettre à jour
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/houzeifa/Mai2025/Projet_UVCI/pct_uvci/mairieYopougon/resources/views/acte/deces/edit.blade.php ENDPATH**/ ?>