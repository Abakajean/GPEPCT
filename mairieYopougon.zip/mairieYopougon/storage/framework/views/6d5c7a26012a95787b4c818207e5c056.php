<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Gestion des actes')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <a href="<?php echo e(route('acte.naissance.index')); ?>" class="bg-blue-100 p-6 rounded-lg hover:bg-blue-200 transition">
                            <h3 class="text-lg font-medium text-blue-800">Actes de naissance</h3>
                            <p class="mt-2 text-blue-600">Gérer les actes de naissance</p>
                        </a>

                        <a href="<?php echo e(route('acte.mariage.index')); ?>" class="bg-green-100 p-6 rounded-lg hover:bg-green-200 transition">
                            <h3 class="text-lg font-medium text-green-800">Actes de mariage</h3>
                            <p class="mt-2 text-green-600">Gérer les actes de mariage</p>
                        </a>

                        <a href="<?php echo e(route('acte.deces.index')); ?>" class="bg-gray-100 p-6 rounded-lg hover:bg-gray-200 transition">
                            <h3 class="text-lg font-medium text-gray-800">Actes de décès</h3>
                            <p class="mt-2 text-gray-600">Gérer les actes de décès</p>
                        </a>

                        <a href="<?php echo e(route('acte.divorce.index')); ?>" class="bg-purple-100 p-6 rounded-lg hover:bg-purple-200 transition">
                            <h3 class="text-lg font-medium text-purple-800">Actes de divorce</h3>
                            <p class="mt-2 text-purple-600">Gérer les actes de divorce</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/houzeifa/Mai2025/Projet_UVCI/mairieYopougon/resources/views/acte/index.blade.php ENDPATH**/ ?>