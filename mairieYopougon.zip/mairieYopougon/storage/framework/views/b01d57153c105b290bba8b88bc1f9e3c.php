<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50">
    <div class="max-w-4xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div class="bg-white shadow-lg rounded-lg overflow-hidden border border-orange-200">
            <!-- Header -->
            <div class="bg-orange-500 px-6 py-4 border-b border-orange-600">
                <h1 class="text-2xl font-bold text-white">Ajouter un acte de divorce</h1>
            </div>
            
            <!-- Form Container -->
            <div class="p-6">
                <form method="POST" action="<?php echo e(route('acte.divorce.store')); ?>" class="space-y-6">
                    <?php echo csrf_field(); ?>
                    
                    <!-- Numéro de registre -->
                    <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                        <div>
                            <label for="numero_registre" class="block text-sm font-medium text-gray-700">Numéro de registre</label>
                            <input type="text" id="numero_registre" name="numero_registre" value="<?php echo e(old('numero_registre')); ?>" 
                                   class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500" 
                                   required maxlength="5" pattern="[0-9]{5}" title="5 chiffres requis">
                            <?php $__errorArgs = ['numero_registre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <!-- Informations ex-conjoint -->
                    <div class="border-t border-gray-200 pt-6">
                        <h2 class="text-lg font-medium text-orange-600 mb-4">Informations sur l'ex-conjoint</h2>
                        <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                            <div>
                                <label for="nom_ex_conjoint" class="block text-sm font-medium text-gray-700">Nom complet</label>
                                <input type="text" id="nom_ex_conjoint" name="nom_ex_conjoint" value="<?php echo e(old('nom_ex_conjoint')); ?>" 
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500" required>
                                <?php $__errorArgs = ['nom_ex_conjoint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div>
                                <label for="date_naissance_ex_conjoint" class="block text-sm font-medium text-gray-700">Date de naissance</label>
                                <input type="date" id="date_naissance_ex_conjoint" name="date_naissance_ex_conjoint" value="<?php echo e(old('date_naissance_ex_conjoint')); ?>" 
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500" required>
                                <?php $__errorArgs = ['date_naissance_ex_conjoint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div>
                                <label for="lieu_naissance_ex_conjoint" class="block text-sm font-medium text-gray-700">Lieu de naissance</label>
                                <input type="text" id="lieu_naissance_ex_conjoint" name="lieu_naissance_ex_conjoint" value="<?php echo e(old('lieu_naissance_ex_conjoint')); ?>" 
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500" required>
                                <?php $__errorArgs = ['lieu_naissance_ex_conjoint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div>
                                <label for="domicile_ex_conjoint" class="block text-sm font-medium text-gray-700">Domicile</label>
                                <input type="text" id="domicile_ex_conjoint" name="domicile_ex_conjoint" value="<?php echo e(old('domicile_ex_conjoint')); ?>" 
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500" required>
                                <?php $__errorArgs = ['domicile_ex_conjoint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Informations ex-conjointe -->
                    <div class="border-t border-gray-200 pt-6">
                        <h2 class="text-lg font-medium text-orange-600 mb-4">Informations sur l'ex-conjointe</h2>
                        <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                            <div>
                                <label for="nom_ex_conjointe" class="block text-sm font-medium text-gray-700">Nom complet</label>
                                <input type="text" id="nom_ex_conjointe" name="nom_ex_conjointe" value="<?php echo e(old('nom_ex_conjointe')); ?>" 
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500" required>
                                <?php $__errorArgs = ['nom_ex_conjointe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div>
                                <label for="date_naissance_ex_conjointe" class="block text-sm font-medium text-gray-700">Date de naissance</label>
                                <input type="date" id="date_naissance_ex_conjointe" name="date_naissance_ex_conjointe" value="<?php echo e(old('date_naissance_ex_conjointe')); ?>" 
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500" required>
                                <?php $__errorArgs = ['date_naissance_ex_conjointe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div>
                                <label for="lieu_naissance_ex_conjointe" class="block text-sm font-medium text-gray-700">Lieu de naissance</label>
                                <input type="text" id="lieu_naissance_ex_conjointe" name="lieu_naissance_ex_conjointe" value="<?php echo e(old('lieu_naissance_ex_conjointe')); ?>" 
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500" required>
                                <?php $__errorArgs = ['lieu_naissance_ex_conjointe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div>
                                <label for="domicile_ex_conjointe" class="block text-sm font-medium text-gray-700">Domicile</label>
                                <input type="text" id="domicile_ex_conjointe" name="domicile_ex_conjointe" value="<?php echo e(old('domicile_ex_conjointe')); ?>" 
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500" required>
                                <?php $__errorArgs = ['domicile_ex_conjointe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Informations sur le jugement -->
                    <div class="border-t border-gray-200 pt-6">
                        <h2 class="text-lg font-medium text-orange-600 mb-4">Informations sur le jugement</h2>
                        <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                            <div>
                                <label for="date_de_jugement" class="block text-sm font-medium text-gray-700">Date du jugement</label>
                                <input type="date" id="date_de_jugement" name="date_de_jugement" value="<?php echo e(old('date_de_jugement')); ?>" 
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500" required>
                                <?php $__errorArgs = ['date_de_jugement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div>
                                <label for="lieu_de_jugement" class="block text-sm font-medium text-gray-700">Lieu du jugement</label>
                                <input type="text" id="lieu_de_jugement" name="lieu_de_jugement" value="<?php echo e(old('lieu_de_jugement')); ?>" 
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500" required>
                                <?php $__errorArgs = ['lieu_de_jugement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Boutons de soumission -->
                    <div class="flex justify-end space-x-4 pt-6 border-t border-gray-200">
                        <a href="<?php echo e(route('acte.divorce.index')); ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500">
                            Annuler
                        </a>
                        <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                            Enregistrer l'acte
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/houzeifa/Mai2025/Projet_UVCI/pct_uvci/mairieYopougon/resources/views/acte/divorce/create.blade.php ENDPATH**/ ?>