<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-4xl mx-auto bg-white rounded-xl shadow-md overflow-hidden p-6">
            <div class="text-center mb-6">
                <h2 class="text-2xl font-bold text-gray-900">
                    <?php if($type == 'naissance'): ?>
                        Acte de Naissance
                    <?php elseif($type == 'mariage'): ?>
                        Acte de Mariage
                    <?php elseif($type == 'deces'): ?>
                        Acte de Décès
                    <?php elseif($type == 'divorce'): ?>
                        Acte de Divorce
                    <?php endif; ?>
                </h2>
                <p class="mt-2 text-sm text-gray-600">Votre paiement a été effectué avec succès</p>
            </div>

            <div class="mb-6 p-4 border border-gray-200 rounded-lg">
                <!-- Afficher les détails de l'acte selon le type -->
                <?php if($type == 'naissance'): ?>
                    <p><strong>Nom de l'enfant:</strong> <?php echo e($acte->nom_enfant); ?> <?php echo e($acte->prenom_enfant); ?></p>
                    <p><strong>Date de naissance:</strong> <?php echo e($acte->date_naissance->format('d/m/Y')); ?></p>
                    <p><strong>Lieu de naissance:</strong> <?php echo e($acte->lieu_naissance); ?></p>
                    <p><strong>Nom du père:</strong> <?php echo e($acte->nom_pere); ?></p>
                    <p><strong>Nom de la mère:</strong> <?php echo e($acte->nom_mere); ?></p>
                <?php elseif($type == 'mariage'): ?>
                    <!-- Détails acte mariage -->
                <?php elseif($type == 'deces'): ?>
                    <!-- Détails acte décès -->
                <?php elseif($type == 'divorce'): ?>
                    <!-- Détails acte divorce -->
                <?php endif; ?>

                <p class="mt-4"><strong>Numéro de registre:</strong> <?php echo e($acte->numero_registre); ?></p>
            </div>

            <div class="flex justify-between items-center">
                <a href="<?php echo e(route('home')); ?>" class="text-blue-600 hover:text-blue-800">
                    Retour à l'accueil
                </a>
                
                <a href="<?php echo e(route('acte.imprimer', ['type' => $type, 'numero' => $acte->numero_registre])); ?>" 
                   class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                    Télécharger l'acte
                </a>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH /home/houzeifa/Mai2025/Projet_UVCI/pct_uvci/mairieYopougon/resources/views/acte/show.blade.php ENDPATH**/ ?>