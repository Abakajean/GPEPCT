<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg overflow-hidden p-8 border border-orange-100">
            <!-- En-tête avec accent orange -->
            <div class="text-center mb-8">
                <div class="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-orange-100 mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <h2 class="text-3xl font-extrabold text-orange-600">Vérification de votre acte</h2>
                <p class="mt-3 text-lg text-gray-600">Veuillez vérifier les informations ci-dessous avant de procéder au paiement</p>
                <div class="mt-4 h-1 bg-gradient-to-r from-orange-400 to-green-500 rounded-full w-32 mx-auto"></div>
            </div>

            <!-- Carte des détails de l'acte -->
            <div class="mb-8 p-6 border border-green-100 rounded-xl bg-green-50">
                <h3 class="text-xl font-semibold text-green-800 mb-4">Détails de l'acte</h3>
                
                <!-- Affichage des détails selon le type -->
                <?php if($type == 'naissance'): ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <p class="text-sm font-medium text-gray-500">Nom complet</p>
                            <p class="text-lg font-semibold text-gray-900"><?php echo e($acte->nom_enfant); ?> <?php echo e($acte->prenom_enfant); ?></p>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">Date de naissance</p>
                            <p class="text-lg font-semibold text-gray-900"><?php echo e($acte->date_naissance->format('d/m/Y')); ?></p>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">Lieu de naissance</p>
                            <p class="text-lg font-semibold text-gray-900"><?php echo e($acte->lieu_naissance); ?></p>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">Nom du père</p>
                            <p class="text-lg font-semibold text-gray-900"><?php echo e($acte->nom_pere); ?></p>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">Nom de la mère</p>
                            <p class="text-lg font-semibold text-gray-900"><?php echo e($acte->nom_mere); ?></p>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">Numéro de registre</p>
                            <p class="text-lg font-semibold text-orange-600"><?php echo e($acte->numero_registre); ?></p>
                        </div>
                    </div>
                <?php elseif($type == 'mariage'): ?>
                    <!-- Détails acte mariage -->
                <?php elseif($type == 'deces'): ?>
                    <!-- Détails acte décès -->
                <?php elseif($type == 'divorce'): ?>
                    <!-- Détails acte divorce -->
                <?php endif; ?>
            </div>

            <!-- Avertissement avec style orange -->
            <div class="bg-orange-50 border-l-4 border-orange-400 p-4 mb-8 rounded-r-lg">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-orange-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <h3 class="text-sm font-medium text-orange-800">Important</h3>
                        <p class="text-sm text-orange-700 mt-1">
                            Veuillez vérifier attentivement les informations ci-dessus. Après paiement, vous pourrez télécharger l'acte.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Bouton de paiement avec dégradé orange-vert -->
            <div class="flex justify-center">
                <a href="<?php echo e(route('paiement.create', ['citoyen' => $citoyen->id])); ?>" 
                   class="inline-flex items-center px-8 py-3 border border-transparent text-lg font-bold rounded-lg shadow-sm text-white bg-gradient-to-r from-orange-500 to-green-500 hover:from-orange-600 hover:to-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 transition duration-300 transform hover:-translate-y-0.5">
                    Procéder au paiement
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ml-2" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                </a>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH /home/houzeifa/Mai2025/Projet_UVCI/pct_uvci/mairieYopougon/resources/views/citoyen/verification.blade.php ENDPATH**/ ?>