<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acte - Mairie de Yopougon</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo {
            width: 100px;
            height: auto;
        }
        .acte-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 2px solid #000;
        }
        .acte-title {
            text-align: center;
            text-decoration: underline;
            margin-bottom: 30px;
        }
        .acte-content {
            margin-bottom: 30px;
        }
        .signature {
            margin-top: 50px;
            text-align: right;
        }
        .footer {
            margin-top: 50px;
            text-align: center;
            font-size: 0.8em;
        }
        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="acte-container">
        <div class="header">
            <h1>RÉPUBLIQUE DE CÔTE D'IVOIRE</h1>
            <h2>Mairie de Yopougon</h2>
        </div>

        <div class="acte-title">
            <h2>
                <?php if($type == 'naissance'): ?>
                    ACTE DE NAISSANCE
                <?php elseif($type == 'mariage'): ?>
                    ACTE DE MARIAGE
                <?php elseif($type == 'deces'): ?>
                    ACTE DE DÉCÈS
                <?php elseif($type == 'divorce'): ?>
                    ACTE DE DIVORCE
                <?php endif; ?>
            </h2>
        </div>

        <div class="acte-content">
            <?php if($type == 'naissance'): ?>
                <p>Numéro de registre: <?php echo e($acte->numero_registre); ?></p>
                <p>Je soussigné, Officier de l'État Civil de la commune de Yopougon, certifie que :</p>
                <p>L'enfant <?php echo e($acte->nom_enfant); ?> <?php echo e($acte->prenom_enfant); ?>,</p>
                <p>Né(e) le <?php echo e($acte->date_naissance->format('d/m/Y')); ?> à <?php echo e($acte->lieu_naissance); ?>,</p>
                <p>Fils/Fille de <?php echo e($acte->nom_et_prenom_pere); ?></p>
                <p>Et de <?php echo e($acte->nom_et_prenom_mere); ?></p>
                
            <?php elseif($type == 'mariage'): ?>
               
            <?php elseif($type == 'deces'): ?>
                
            <?php elseif($type == 'divorce'): ?>
                
            <?php endif; ?>
        </div>

        <div class="signature">
            <p>Fait à Yopougon, le <?php echo e(now()->format('d/m/Y')); ?></p>
            <p>L'Officier de l'État Civil</p>
        </div>

        
    </div>

    <div class="no-print" style="text-align: center; margin-top: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer;">
            Imprimer
        </button>
    </div>
</body>
</html><?php /**PATH /home/houzeifa/Mai2025/Projet_UVCI/pct_uvci/GPEPCT/mairieYopougon/resources/views/acte/download.blade.php ENDPATH**/ ?>