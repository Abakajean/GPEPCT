<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Tableau de bord')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <!-- Statistiques -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Statistiques générales</h3>
                    <div class="space-y-4">
                        <div>
                            <p class="text-sm text-gray-500">Nombre total de demandes</p>
                            <p class="text-2xl font-bold"><?php echo e($stats['demandes']); ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Montant total des paiements</p>
                            <p class="text-2xl font-bold"><?php echo e(number_format($stats['paiements'], 0, ',', ' ')); ?> FCFA</p>
                        </div>
                    </div>
                </div>

                <!-- Actes -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Statistiques des actes</h3>
                    <div class="space-y-4">
                        <div>
                            <p class="text-sm text-gray-500">Actes de naissance</p>
                            <p class="text-2xl font-bold"><?php echo e($stats['naissances']); ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Actes de mariage</p>
                            <p class="text-2xl font-bold"><?php echo e($stats['mariages']); ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Actes de décès</p>
                            <p class="text-2xl font-bold"><?php echo e($stats['deces']); ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Actes de divorce</p>
                            <p class="text-2xl font-bold"><?php echo e($stats['divorces']); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Autres statistiques -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Répartition géographique</h3>
                    <!-- Ici vous pourriez ajouter un graphique ou d'autres statistiques -->
                    <div class="h-64 flex items-center justify-center text-gray-400">
                        [Graphique de répartition géographique]
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/houzeifa/Mai2025/Projet_UVCI/mairieYopougon/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>